%HECHOS
%empleado(dni, nombre, apelledio, telefono, domicilio(calle,numero))
empleado('26134236','Micaela','Sanchez','958778',domicilio('Drago',321)).
empleado('18524336','Susana','Lombardo','874777',domicilio('Mendoza',534)).
empleado('17143236','Luisa','Estrada','458900',domicilio('Entre Rios',1321)).
empleado('12345246','Roberto','Lujan','667766',domicilio('Paz',2123)).
%ventas(codigo, dni, fecha(dia,mes,anio),lista)
ventas(1,'26134236',fecha(12,5,2020),['A','B','C']).
ventas(2,'17143236',fecha(12,5,2020),['B','C']).
ventas(3,'26134236',fecha(18,5,2020),['D','E']).
ventas(4,'17143236',fecha(18,5,2020),['A','D','E']).
ventas(5,'17143236',fecha(19,3,2020),['F']).
%�tem(codigo, descripcion)
�tem('A','Bateria').
�tem('B','Motor').
�tem('C','Chasis').
�tem('D','Asientos').
�tem('E','Caja de velocidad').
�tem('F','Compresor').

% 1) Conocer el dni del empleado, su telefono y la cantidad de items,
% para un determinado pedido cuyo c�digo de compras se
% especifica. Predicado sugerido para esta regla: regla1/4. (15 puntos)
% codigo compra, dni, telefono y cantidad de items
regla1(CC,DNI, TEL, CI) :- ventas(CC, DNI, _, L),
                            empleado(DNI, _, _, TEL, _),
                            length(L, CI).

%2)	Conocer si existe o no existe alg�n �tem de compras
%registrado cuya descripci�n sea  Asientos o Caja de Velocidad
%para cierto c�digo de pedido. Nombre de la regla: regla2/1.
regla2(CC) :- ventas(CC, _, _, L),
              member(CI,L),
              �tem(CI, DE),
              (DE == 'Asientos' ; DE == 'Caja de velocidad'),
              !.

%3)     Generar una lista con los DNI de aquellos empleados
% que tuvieron alguna compra durante el mes y a�o que se
% especifique. Considerar la posibilidad que un mismo empleado
% haya comprado m�s de una vez en ese mes y a�o,
% por lo que se deber� evitar que su DNI figure repetido
% tantas veces en ese mismo mes y a�o.
% Predicado sugerido para esta regla: regla3/3. (20 puntos)
% findall(DNI, buscar DNI, L)
% auxiliar
buscar(M, A, DNI) :- ventas(_, DNI, fecha(_, M, A), _).
regla3(M, A, LO) :- findall(DNI, buscar(M, A, DNI), L), sort(L, LO).

%4)     Generar una lista con los nombres de aquellos empleados
% que tuvieron alguna compra durante el mes y a�o que se
% especifique. Considerar la posibilidad que un mismo empleado
% haya comprado m�s de una vez en ese mes y a�o,
% por lo que se deber� evitar que su nombre figure repetido
% tantas veces en ese mismo mes y a�o.
% Predicado sugerido para esta regla: regla4/3. (20 puntos)
% findall(Nombre, buscar Nombre, L)
% auxiliar
buscar2(M, A, NE) :- ventas(_, DNI, fecha(_, M, A), _),
                     empleado(DNI, NE, _, _, _).

regla4(M, A, LO) :- findall(NE, buscar2(M, A, NE), L), sort(L,LO).

