{- 1) Realizar una función que reciba el puntaje obtenido en las compras 
de los ítems especificados para un empleado y retorne la categoría resultante. 
En el caso de que el puntaje no se encuentre ninguno de los rangos especificados
 en la Tabla 1 la función deberá retornar un mensaje de “Puntaje erróneo”.
90 a 100	“Nivel Máximo”
80 a 89	“Nivel Muy Bueno”
60 a 79	“Nivel Bueno”
45 a 59	“Nivel Regular”
0 a 44	“Nivel Reprobado”
-}

funcion1::Int -> String
funcion1 p | (p >= 90 && p <= 100) = "Nivel Maximo"
	   | (p >= 80 && p <= 89) = "Nivel Muy Bueno"
	   | (p >= 60 && p <= 79) = "Nivel Bueno"
	   | (p >= 45 && p <= 59) = "Nivel Regular"
	   | (p >= 0 && p <= 44) = "Nivel Reprobado"
           | otherwise = "Puntaje erroneo"

lista :: [Integer]
lista = [60, 80, 42, 95, 100, 89]

{- Realizar una función que genere una nueva lista con los puntajes que 
pertenezcan a un determinado rango. Considerar como parámetros de la función: 
la lista con los puntajes de todos los empleados de compras, el rango inferior 
y superior. (15 puntos)
-}
funcion2:: [Integer] -> Integer -> Integer -> [Integer]
--comprension
funcion2 lista inf sup = [ x | x <- lista,  (x >= inf && x <= sup)]
--recursividad
funcion2b:: [Integer] -> Integer -> Integer -> [Integer]
funcion2b [] _ _ = []
funcion2b (x:xs) inf sup = if (x >= inf && x <= sup)
				then x : funcion2b xs inf sup
				else funcion2b xs inf sup


{- 3) Realizar una función que permita retornar la cantidad de puntajes que
 sean superior a un valor “x”. 
Considerar como parámetros de la función: la lista con los puntajes de todos 
los empleados de compras y el valor “x”. Para resolver este punto debe 
definir una función recursiva. (20 puntos)
-}
funcion3::[Integer] -> Integer -> Integer
funcion3 [] _ = 0
funcion3 (h:hs) x = if (h > x)
			then 1 + funcion3 hs x
			else funcion3 hs x




