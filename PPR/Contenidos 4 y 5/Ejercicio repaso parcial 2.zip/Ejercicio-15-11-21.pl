%pedido(numeroPedido, numeroINterno, HoraExacta(hora,minutos),
% listadoArticulos, importe, tipoCobro)
pedido(1,'333',hora_exacta(7,30),['caf�','caf�','factura','factura'],300,'TC').
pedido(2,'444',hora_exacta(9,20),['gaseosa','torta'],500,'TC').
pedido(3,'111',hora_exacta(9,25),['factura','criollo','criollo'],150,'E').
pedido(4,'444',hora_exacta(10,15),['sandwich','sandwich','torta'],800,'TC').
pedido(5,'333',hora_exacta(10,25),['caf�','caf�'],200,'E').
pedido(6,'444',hora_exacta(10,40),['sandwich','factura','caf�'],600,'D').

%oficina(numeroInterno, descripcion, ubicacion)
oficina('111','Biblioteca','Ala A').
oficina('222','Laboratorio','Ala B').
oficina('333','Sala de maestros','Lateral D').
oficina('444','Direcci�n','Central').

%recargo(tipoCobre, descripcion, porcentaje)
recargo('E','efectivo',0).
recargo('D','d�bito',10).
recargo('TC','tarjeta de cr�dito',25).

%1.	Conocer si entre los pedidos recibidos, hubo o no hubo, alg�n pedido cuyo importe final est� comprendido entre 2 valores
% que se reciben como argumentos en la regla, incluyendo ambos extremos.
% Tener en cuenta que el importe final se calcula increment�ndole al
% importe del pedido, el porcentaje del mismo, correspondiente al tipo de
% cobro, especificado en la tabla 3. Predicado sugerido para esta regla:
% regla1/2. (15 puntos)
% I --100
% x --PR
%

regla1aux(IF, NP) :- pedido(NP, _, _, _, I, TC),
                  recargo(TC, _, PR),
                  IF is (I + (PR * I / 100)).

regla1(VI, VF) :- regla1aux(IF,_),
                  (IF >= VI , IF =< VF),
                  !.

%2.	Conocer para un determinado n�mero de pedido que tambi�n se deber� especificar como argumento a la
% regla, los siguientes datos: descripci�n de la oficina/departamento
% desde el cual se hizo el pedido, hora y minuto (por separado) en el que
% se recibi� el pedido, descripci�n del tipo de cobro, e importe final
% del pedido. Recordar que el importe final se calcula increment�ndole al
% importe del pedido, el porcentaje del mismo, correspondiente al tipo de
% cobro, especificado en la tabla 3. Predicado sugerido para esta regla:
% regla2/6. (15 puntos)
%
regla2(NP, DO, HO, MI, DC, IF) :- pedido(NP,NI,hora_exacta(HO, MI),_,_,TC),
                                  oficina(NI,DO,_),
                                  recargo(TC,DC,_),
                                  regla1aux(IF,NP).


%3.	Generar una lista con las descripciones de aquellas oficinas/departamentos que hayan realizado alg�n
% pedido en el cual el listado de art�culos correspondiente tenga una
% cantidad mayor a N, siendo N un valor especificado en la regla. En la
% lista a generar no deber�n figurar descripciones o nombres de
% oficinas/departamentos repetidos en caso que dicha oficina/departamento
% tenga m�s de un pedido en el que figuren en sus listados de art�culos
% una cantidad de art�culos mayor a N; por lo tanto se deber�n eliminar
% de la lista a generar aquellos nombres de oficinas/departamentos que
% llegaran a estar repetidos. Predicado sugerido para esta regla:
% regla3/2. (20 puntos)
%
regla3aux(D, N) :- pedido(_,NI,_,LA,_,_),
                    oficina(NI,D,_),
                    length(LA, CA),
                    CA > N.

regla3(LO, N) :- findall(D, regla3aux(D, N), L), sort(L,LO).






