--funcion 1
--1)	Crear una función en Haskell que retorne el precio a pagar por paquete. 
--(Los parámetros deberían ser la cantidad de días y el código de paquete que se compra).
funcion1::Int->Int->Float
--con case
{-funcion1 dias codigo = case codigo of
			  1 -> fromIntegral(1000 * dias)
			  2 -> fromIntegral(500 * dias)
			  3 -> fromIntegral(500 * dias) 
			  4 -> fromIntegral(250 * dias)
			  _ -> 0.0  
-}
--con guardas
funcion1 dias codigo | (codigo == 1) = fromIntegral(1000 * dias)
		     | (codigo == 2 || codigo == 3) = fromIntegral(500 * dias)
		     | (codigo == 4) = fromIntegral(250 * dias)
		     | otherwise = 0

--2)	Crear una función en Haskell que dado un código de paquete retorne el nombre del mismo.
funcion2::Int -> String
funcion2 codigo = case codigo of
		     1 -> "Publicidad en carteles"
		     2 -> "Publicidad en radio"
		     3 -> "Publicidad en television"
		     4 -> "Publicidad en redes sociales"
		     _ -> "Codigo no existe"

--3)	Crear una función que retorne el nombre de la categoría, 
--tomando como parámetros de entrada el monto de inversión. 
funcion3::Float -> String
funcion3 monto  | (monto >= 1000 && monto < 5000) = "Inicial"
		| (monto >= 5000 && monto < 15000) = "Consolidado"
		| (monto >= 15000 && monto < 50000) = "Premium"
		| (monto >= 50000) = "Super Cliente"
		| otherwise = "No aplica categoria"

--4)	Crear una función que retorne el código de la categoría, tomando como parámetros de entrada el monto de inversión. 
funcion4::Float -> Int
funcion4 monto  | (monto >= 1000 && monto < 5000) = 1
		| (monto >= 5000 && monto < 15000) = 2
		| (monto >= 15000 && monto < 50000) = 3
		| (monto >= 50000) = 4
		| otherwise = 0

--5)	Crear una función que retorne el precio a pagar de cada paquete, 
--tomando como parámetros de entrada el monto de inversión y
-- la cantidad de días. --(considerar que el código de paquete varía según el monto de inversión) 
--reutiliza la funcion del punto 4 para obtener el codigo del paquete
--reutiliza la funcion 1 para obtener el importe a pagar 

{-
punto5 :: Float ->Int ->Float
punto5 monto cd = punto1 (punto4 monto) cd
-}

funcion5::Float->Int->Float
--usando let
funcion5 monto dias = let codigo = funcion4 monto in funcion1 dias codigo
--usando where
--funcion5 monto dias = (funcion1 dias codigo)
			where codigo = funcion4 monto











