cuadrado::Int -> Int
cuadrado x = x * x

--curried
suma:: Int->Int -> Int
suma a b = a + b

--Uncurried
suma2:: (Int,Int) -> Int
suma2 (a,b) = a + b

cubo::Int -> Int
cubo x = x * x * x

