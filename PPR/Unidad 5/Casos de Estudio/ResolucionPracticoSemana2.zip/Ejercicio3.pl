%HECHOS
%vendedor/3- vendedor(Legajo,Nombre,Apellido)
vendedor(1,'Francesca','Luchetti').
vendedor(2,'Vera','Petro').
vendedor(3,'Lara','Tana').
%venta/5 - venta(C�digoVenta,LegajoVendedor,importeFacturado, fechaVenta,TipoCobro)
%fechaVenta/3 - fechaVenta(D�a,Mes,A�o)
%TipoCobro: tarjeta/2, efectivo/1.
%tarjeta/2 - tarjeta(NroCup�n,CantidadCuotas)
%efectivo/1 - efectivo(DebitoSiNO)
venta(111,1,355.5,fechaVenta(23,9,2013),tarjeta(610,3)).
venta(222,2,230.45,fechaVenta(25,9,2013),efectivo('si')).
venta(333,1,1834.25,fechaVenta(23,8,2013),tarjeta(410,4)).
venta(444,2,2000.25,fechaVenta(23,8,2013),tarjeta(200,4)).

% 1) �El vendedor X (nombre), hizo alguna venta?
regla1(X) :- vendedor(LV, X, _), venta(_, LV, _, _, _), !.

%  2) �El vendedor X (nombre), que ventas hizo? Mostrar los c�digos de
% ventas.
regla2(X, C) :- vendedor(LV, X, _), venta(C, LV, _, _, _).

%  3) Los c�digos de las ventas en la que se haya facturado m�s de X
%  pesos durante el mes de septiembre de 2013.
regla3(C, X) :- venta(C, _, I, fechaVenta(_, 9, 2013), _),
                I > X.

% 4) Los c�digos de las ventas cobradas con tarjeta de cr�dito
% usando no m�s de 6 cuotas o mediante efectivo pero con d�bito
% autom�tico.
regla4(C) :- venta(C, _, _, _, TC),
            (    (TC = tarjeta(_,CC), CC =< 6);
                 (TC = efectivo('si'))
            ).







