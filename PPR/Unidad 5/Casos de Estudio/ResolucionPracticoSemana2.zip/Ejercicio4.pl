%localidad(codigoLocalidad, nombre, codigoPostal)
localidad(1,'Cordoba',5000).
localidad(2,'Buenos Aires', 5660).
localidad(3,'Mendoza',5500).
localidad(4,'Rosario',6000).
localidad(5,'Misiones',6500).

%pedido(codigoPedido,listaProductos)
pedido(1, ['Ropa','Perfume','Filmadora','Tablet']).
pedido(2, ['Tablet','Zapatillas']).
pedido(3, ['Camara','Ropa','Zapatos']).
pedido(4, ['DVD','Libros']).

% ordenCompra(numeroOrden,
% fecha(dia,mes,anio),cliente(nombre,codigoLocalidad),codigoPedido,total)

ordenCompra(1,fecha(10,6,2014),cliente('Juan Garcia',1),1,1500).
ordenCompra(2,fecha(12,7,2012),cliente('German Prueba',3),2,2000).
ordenCompra(3,fecha(23,12,2013),cliente('Ivana Testa',5),3,3500).
ordenCompra(4,fecha(30,11,2013),cliente('Laura Rodriguez',4),3,3500).
ordenCompra(5,fecha(15,5,2014),cliente('Carlos Perez',3),2,2000).
ordenCompra(6,fecha(2,5,2014),cliente('Carola Reina',2),1,1500).
ordenCompra(7,fecha(6,4,2014),cliente('Estaban Alves',1),4,800).


%I.	El total ganado en las �rdenes de compra para una localidad X durante un a�o determinado. Nombre sugerido punto1/3.
aux1(CL, A, T) :- ordenCompra(_,fecha(_,_,A),cliente(_,CL),_,T).
punto1(CL,A,TG) :- findall(T, aux1(CL,A,T),L), sumlist(L,TG).


%II.	Listar el nombre de los clientes que hayan pedido m�s de 2 productos en un pedido. Nombre sugerido punto2/1.
aux2(N) :- ordenCompra(_,_,cliente(N,_),CP,_), pedido(CP,L), length(L,C), C > 2.
punto2(L) :- findall(N,aux2(N),L).

%III.	Listar los productos (sin repetir), de todas aquellas �rdenes de compra de Buenos Aires o Rosario. Nombre sugerido punto3/1.
aux3(NP) :- localidad(CL,_,_), (CL == 2; CL == 4), ordenCompra(_,_,cliente(_,CL),CP,_),pedido(CP,L),member(NP,L).
punto3(LO) :- findall(NP, aux3(NP), L), sort(L, LO).


